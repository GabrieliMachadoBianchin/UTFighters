using System.Collections;
using UnityEngine;

public class PlayerCombat : MonoBehaviour
{
    [Header("Teclas")]
    public KeyCode punchKey;
    public KeyCode kickKey;
    public KeyCode specialKey;

    [Header("Tempo dos golpes")]
    public float attackDuration = 0.25f;

    private CharacterVisual characterVisual;
    private bool isAttacking;

    private void Awake()
    {
        characterVisual = GetComponent<CharacterVisual>();
    }

    void Update()
    {
        if (isAttacking)
            return;

        if (Input.GetKeyDown(punchKey))
        {
            StartCoroutine(Attack(CharacterState.Punch));
        }

        if (Input.GetKeyDown(kickKey))
        {
            StartCoroutine(Attack(CharacterState.Kick));
        }

        if (Input.GetKeyDown(specialKey))
        {
            StartCoroutine(Attack(CharacterState.Special));
        }
    }

    IEnumerator Attack(CharacterState state)
    {
        isAttacking = true;

        characterVisual.SetState(state);

        yield return new WaitForSeconds(attackDuration);

        characterVisual.SetState(CharacterState.Idle);

        isAttacking = false;
    }
}